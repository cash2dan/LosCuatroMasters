Lägg till historik för upplaga I och II på Mästerskapet-sidan.

═══════════════════════════════════════════════
PLACERING
═══════════════════════════════════════════════

Historiken läggs in efter "Deltagarna"-sektionen, i kronologisk
ordning: Upplaga I (2024) → Upplaga II (2025) → Upplaga III (2026).

Den befintliga texten under rubriken "Upplaga I" ska ERSÄTTAS med den
nya versionen nedan. Texten under "Upplaga III" lämnas som den är.

═══════════════════════════════════════════════
UPPLAGA I — 2024
═══════════════════════════════════════════════

Ny text (ersätter den befintliga):

Den första upplagan avgjordes över två dagar: La Cala Resort, Campo
Asia den 6 september, och Atalaya Golf, Old Course den 7 september.

Inga scorekort finns bevarade. Vad som då utspelade sig tillhör därmed
den muntliga traditionen, där segrarens identitet växlar beroende på
vem som berättar och hur sent på kvällen det sker.

═══════════════════════════════════════════════
UPPLAGA II — 2025
═══════════════════════════════════════════════

Ny sektion. Ska vara HOPFÄLLBAR: slutställningen syns direkt, resten
fälls ut via en knapp ("Visa detaljer" / "Dölj detaljer" eller
liknande).

── SYNLIGT DIREKT ──

Rubrik: UPPLAGA II — 2025

Kort inledning:
Mästerskapets andra upplaga spelades över tre rundor i Andalusien.
Lars Munther tog titeln med tolv slags marginal.

Slutställning (visa placering, namn, totalt antal slag, samt över par):

1. Lars        255  (+39)
2. Per         267  (+51)
3. Jonsson     288  (+72)
4. Johansson   378  (+162)

Använd samma visuella stil som Leaderboard-sidan (guldfärgat kort för
vinnaren, spelarens färg som prick, monospace för siffrorna).

── UTFÄLLBART ──

RUNDORNA

19 september · Los Naranjos Golf Club · par 72
  Lars 89 (+17) · Per 91 (+19) · Jonsson 99 (+27) · Johansson 128 (+56)

20 september · Santana Golf · par 72
  Lars 83 (+11) · Per 83 (+11) · Jonsson 92 (+20) · Johansson 129 (+57)

21 september · Mijas Golf, Los Lagos · par 72
  Lars 83 (+11) · Per 93 (+21) · Jonsson 97 (+25) · Johansson 121 (+49)

Lägg gärna in en not: Santana spelades även 2025, vilket gör årets
fredagsrunda direkt jämförbar.

DREAM 18

Lägsta score per hålnummer över alla tre rundor, summerat:

Per         67
Lars        73
Jonsson     81
Johansson  102

Not att visa under tabellen:
Per vann Dream 18 med sex slag trots att han förlorade mästerskapet
med tolv. Hans bästa hål var bättre — Lars var jämnare.

AWARDS 2025

Comeback King    Per, Jonsson och Johansson (delad, +4 slag)
Mr Consistency   Lars (±0,87)
Ice Man          Lars (0,17 slag bättre på sista tre)
Streak Master    Per (16 hål i rad utan dubbel)
Birdie Machine   Lars (4 birdies)

Iron Man, Fairway Finder, Putting Wizard, Houdini och The Optimizer
visas som "—" med noten: Statistik för GIR, puttar och öl saknas för
2025.

Använd samma kortlayout och ikoner som Awards-sidan använder, så det
känns enhetligt. Comeback King ska visa alla tre vinnarna.

═══════════════════════════════════════════════
DATA
═══════════════════════════════════════════════

Lägg 2025 års kompletta hål-för-hål-data som en konstant i src/data.js
(t.ex. EDITION_2025), strukturerad så att den kan användas för fler
vyer senare. Alla siffror ovan är redan uträknade och verifierade —
lägg in dem som de är, räkna inte om dem i appen.

Datan ska INTE skrivas till Firestore. Det är statisk historik, inget
som ska synkas eller kunna ändras.

Kompletta scorekort per runda och spelare finns i de tre CSV-filerna
som jag lägger i projektmappen. Strukturera om dem till samma
hålformat som appen använder i övrigt.

Spelarnamnen i CSV-filerna är Per Welin, Lars Munther, Daniel Jonsson
och Daniel Johansson. Mappa dem till appens befintliga spelar-id:n
(per, lars, jonsson, johansson).

═══════════════════════════════════════════════
ÖVRIGT
═══════════════════════════════════════════════

- Texterna som konstanter i src/data.js, inte hårdkodat i JSX
- Kör npm run build och verifiera att det går igenom rent
- Testa med npm run dev innan du är klar
- Uppdatera CLAUDE.md
